<?php
	define('DB_HOST','localhost');
	define('DB_USUARIO','root');
	define('DB_CONTRA','');
	define('DB_NOMBRE','principal');
	define('DB_CHARSET','utf8');
?>
