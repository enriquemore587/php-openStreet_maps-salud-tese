var nivel = 0;
var map;
var vector1;
var vector2;
var delegaciones;
var namesDelegaciones =  ['GUSTAVO A. MADERO (D-F)','AZCAPOTZALCO (D-F)','MIGUEL HIDALGO (D-F)','CUAUHTEMOC (D-F)','VENUSTIANO CARRANZA (D-F)','IZTACALCO (D-F)','BENITO JUAREZ (D-F)','CUAJIMALPA DE MORELOS (D-F)','IZTAPALAPA (D-F)','ALVARO OBREGON (D-F)','COYOACAN (D-F)','MAGDALENA CONTRERAS, LA (D-F)', 'TLAHUAC (D-F)','XOCHIMILCO (D-F)','TLALPAN (D-F)','MILPA ALTA (D-F)']
var unidades = [];
var delegaciones = [];
var afecciones = [];
var fecha = [];
